<?php 
$nombre = "Cosme Fulanito";

function saludar($nombre, $apellido){
    echo "Hola ". $nombre . " Tu apellido es ". $apellido . "<br>";

}

saludar("Cosme", "Fulano");
saludar("Juan" , "Perez");

