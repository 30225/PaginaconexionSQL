<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/estilos.css">
    <title>PHP y Wordpress</title>
</head>
<body>
    <header>
        <nav class="botonera_principal">
            <ul>
                <li> <a href="index.php">Home </a> </li>
                <li> <a href="index.php">Noticias </a> </li>
                <li> <a href="tienda.php">Leer </a> </li>
                <li> <a href="contacto.php">Contacto </a> </li>
            </ul>

        </nav>

    </header>